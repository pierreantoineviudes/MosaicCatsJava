package cat.mosaic.constants;


public class InOutConstants {
    public static final String catInputPath = "D:/Fichiers PA/dev/cats_dataset/archive";
    public static final String mosaicTilesOutputPath = "D:/Fichiers PA/dev/cats_mosaic/mocaiscats/atlas.jpg";
    public static final int TileSize = 32;
}
