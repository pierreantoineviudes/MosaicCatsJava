package cat.mosaic.app;

public class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("Task executed by " + Thread.currentThread().getName());
    }
}
