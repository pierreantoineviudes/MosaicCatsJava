package cat.mosaic.app;

import cat.mosaic.constants.InOutConstants;
import cat.mosaic.utils.ImageFileLister;
import cat.mosaic.utils.ImageUtils;


import java.awt.image.BufferedImage;

import java.io.File;


import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class OpenImagesWithQueues {

    public static int N_IMAGES = 50;
    public static int imageCounter = 0;
    public static int N_THREAD_CONSUMER = 5;
    public static int N_THREAD_PRODUCER = 5;
    public static BufferedImage POISON = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);

    static void main() {

//         Count the image files
        ImageFileLister.listImage(InOutConstants.catInputPath);
        System.out.println(ImageFileLister.nFiles);


        BlockingQueue<BufferedImage> imageQueue = new ArrayBlockingQueue<>(32);


//         Create producer with multiple Threads
        Thread producer = new Thread(() -> {
            for (File file : ImageFileLister.imageFiles) {
                imageCounter += 1;
                if (imageCounter > N_IMAGES) {
//                    send stop to the queue
                    for (int i = 0; i < N_THREAD_CONSUMER; i++) {
                        try {
                            imageQueue.put(POISON);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    break;
                }
                BufferedImage img = ImageUtils.openImage(file);
                try {
                    imageQueue.put(img);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });


//        Create a consumer threadPool

        for (int i = 0; i < N_THREAD_CONSUMER; i++) {
            Thread consumer = new Thread(() -> {
                while (true) {
                    try {
                        BufferedImage img = imageQueue.take();
                        if ((img.getHeight() == 1) & (img.getWidth() == 1)) {
                            System.out.println("exiting thread reader");
                            break;
                        }
                        System.out.println("Consumed image in thread");
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }

                }
            });
            consumer.start();
        }

        producer.start();

    }
}
