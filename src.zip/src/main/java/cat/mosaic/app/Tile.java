package cat.mosaic.app;

import java.awt.image.BufferedImage;

public class Tile {
    private BufferedImage img;
    private int index;

    public Tile(BufferedImage img, int index) {
        this.index = index;
        this.img = img;
    }

    public int getIndex() {
        return this.index;
    }

    public BufferedImage getImg() {
        return this.img;
    }
}
