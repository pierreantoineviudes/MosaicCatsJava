package cat.mosaic.app;

public class BenchmarkNumberThread {
}
