package cat.mosaic.app;

import cat.mosaic.constants.InOutConstants;
import cat.mosaic.utils.ImageFileLister;
import cat.mosaic.utils.ImageUtils;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;

import java.nio.Buffer;
import java.util.List;
import java.util.concurrent.*;

public class MosaicApp {

    //    Open the tiles in a queue with low threadPool
    public static void main2() {

//        list files to open
        ImageFileLister.listImage(InOutConstants.catInputPath);
        List<File> files = ImageFileLister.imageFiles;

//        create all necessary queues
        ExecutorService ioPool = Executors.newFixedThreadPool(2);
        int numberCoresAvailable = Runtime.getRuntime().availableProcessors();
        System.out.println("numberCoresAvailable : " + numberCoresAvailable);
        ExecutorService cpuPool = Executors.newFixedThreadPool(numberCoresAvailable);
        BlockingQueue<BufferedImage> readQueue = new ArrayBlockingQueue<>(32);

//        create reader and feed the queue
        for (File file : files) {
            ioPool.submit(() -> {
                BufferedImage img = ImageUtils.openImage(file);
                try {
                    assert img != null;
                    System.out.println("in the i/o pool");
                    readQueue.put(img);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }

//        try to consume the queue
        for (int i = 0; i < numberCoresAvailable; i++) {
            cpuPool.submit(() -> {
                        System.out.println("in the CPU loop");
                        while (true) {
                            System.out.println("in While loop");
                            try {
                                BufferedImage img = readQueue.take();
                                System.out.println("before return");
                                return img;
                            } catch (InterruptedException e) {
                                System.out.println(e);
                                throw new RuntimeException(e);
                            }

                        }
                    }
            );
        }


//        resize the images in the queue
//        List<Future<BufferedImage>> resized = new ArrayList<>();
//        for (int i = 0; i < numberCoresAvailable; i++) {
//            resized.add(cpuPool.submit(() -> {
//                                BufferedImage img = readQueue.take();
//                                System.out.println("in the cpu pool");
//                                return ImageUtils.resize(img, InOutConstants.TileSize);
//                            }
//                    )
//
//            );
//        }
    }

    //    Resize the opened images with high threadPools CPU bounded operation
//    add this to the big Image
//    save the big image as a jpg
    public static void main3() throws InterruptedException {
        ImageFileLister.listImage(InOutConstants.catInputPath);
        List<File> files2 = ImageFileLister.imageFiles;
        // 1. Pools
        ExecutorService ioPool2 = Executors.newFixedThreadPool(2);
        ExecutorService cpuPool2 = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        ExecutorService cpuPool3 = Executors.newFixedThreadPool(4);

// 2. Queues
        BlockingQueue<BufferedImage> fileQueue = new ArrayBlockingQueue<>(32);
        BlockingQueue<BufferedImage> resizedQueue = new ArrayBlockingQueue<>(32);

// 3. Submit I/O tasks
        for (File p : files2) {
            ioPool2.submit(() -> {
                BufferedImage img = ImageUtils.openImage(p);
                try {
                    fileQueue.put(img);
//                    System.out.println("Submitted in fileQueue");
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        // 2. After all files submitted, send poison pills
        BufferedImage POISON = null;
        for (int i = 0; i < 3; i++) {
            fileQueue.put(POISON); // poison pill for each CPU thread
            System.out.println("poison sent");
        }

// 4. Submit CPU tasks
        for (int i = 0; i < Runtime.getRuntime().availableProcessors(); i++) {
            cpuPool2.submit(() -> {
                while (true) {
                    BufferedImage img = null;
                    try {
                        img = fileQueue.take();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    if (img == null) {
                        System.out.println("going out of loop");
                        try {
                            resizedQueue.put(img);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                    }
                    BufferedImage resized = ImageUtils.resize(img, InOutConstants.TileSize);
                    try {
                        resizedQueue.put(resized);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
//                    System.out.println("Submitted in resizedqueue");
                }
            });
        }

//         consume from the cpuPool2 otherwise it will be full
        for (int i = 0; i < 4; i++) {
            cpuPool3.submit(() -> {
                while (true) {
                    BufferedImage img = null;
                    try {
                        img = resizedQueue.take();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    if (img == null) {
                        System.out.println(("going out of loop"));
                        break;
                    }
//                    System.out.println("read from resized queue");
                }
            });
        }


// 5. Shutdown
        ioPool2.shutdown();
        cpuPool2.shutdown();
    }

    public static void main(){

    }
}
