package cat.mosaic.app;

import cat.mosaic.utils.ImageUtils;

import java.awt.image.BufferedImage;
import java.util.concurrent.BlockingQueue;


public class ImageReader implements Runnable {
    private final BlockingQueue<Tile> queue;
    private final int TileSize;
    private final BufferedImage finalImage;

    public ImageReader(BlockingQueue<Tile> queue, int TileSize, BufferedImage finalImage) {
        this.queue = queue;
        this.TileSize = TileSize;
        this.finalImage = finalImage;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Tile tile = this.queue.take();
                int index = tile.getIndex();
                System.out.println("index : " + index);
                if (index == -1) {
                    System.out.println("breaking");
//                    stop the thread
                    break;
                }
                BufferedImage img = tile.getImg();
                BufferedImage resized = ImageUtils.resize(img, this.TileSize);
                int row = index / (finalImage.getWidth() / TileSize);
                int col = index % (finalImage.getWidth() / TileSize);
                int x0 = col * TileSize;
                int y0 = row * TileSize;
                synchronized (finalImage) {
                    finalImage.getRaster().setRect(x0, y0, resized.getRaster());
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }

    }
}
