package cat.mosaic.utils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class ImageUtils {

    public static BufferedImage openImage(File file) {
        try {
            BufferedImage img = ImageIO.read(file);

            if (img == null) {
                throw new IOException("ImageIO returned null");
            }

            // Force RGB to avoid CMYK / grayscale issues
            BufferedImage rgb = new BufferedImage(
                    img.getWidth(),
                    img.getHeight(),
                    BufferedImage.TYPE_INT_RGB
            );

            rgb.getGraphics().drawImage(img, 0, 0, null);

            return rgb;

        } catch (Exception e) {
            System.err.println("Failed to open image: " + file.getAbsolutePath());
            return null;
        }
    }


    public static int[] getPixelsImage(BufferedImage bufferedImage, int x, int y) {
        int rgb = bufferedImage.getRGB(x, y);

        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return new int[]{r, g, b};
    }


    public static void writeImageJPG(BufferedImage bufferedImage, String outputPath) throws IOException {
        System.out.println("saving to " + outputPath);
        ImageIO.write(bufferedImage, "jpg", new File(outputPath + ".jpg"));
    }


    public static BufferedImage resize(BufferedImage img, int TileSize) {
        BufferedImage resized = new BufferedImage(TileSize, TileSize, img.getType());
        Graphics2D g = resized.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(img, 0, 0, TileSize, TileSize, null);
        g.dispose();
        return resized;
    }
}
